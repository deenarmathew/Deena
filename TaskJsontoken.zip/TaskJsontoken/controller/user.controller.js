const UserModel=require('../model/user') 
const bcrypt=require('bcryptjs')  //import bcryptjs form package
const  jwt=require('jsonwebtoken');// import jsonwebtoken form package and assign to jwt

const RegisterUser= async (req,res)=>{
   //hash password
 const hashedpassword = await bcrypt.hash(req.body.password,10)
 UserModel.create({username:req.body.username,email:req.body.email,password:hashedpassword}).then((create)=>{
  res.json(create)
 })}
 
    const getUser=(req,res)=>{
    UserModel.findAll().then((getall)=>{
     res.json(getall)

    })}


  const LoginUser= async (req,res)=>{
      try{
         const user= await UserModel.findOne({email:req.body.email});
       if(user && (await  bcrypt.compare(req.body.password,user.password))){
        //create token
              const token = jwt.sign( 
             {email:req.body.email},
               'TOKEN_KEY',
            {
              expiresIn: "5h",
            }
          );
           res.json({email:req.body.email,token:token});
       }else{
        res.json({message:"invalid Credentials"})
    }}catch(error){
        console.log(error)
 }}
 
 //token verification process
const verifytoken=  async (req,res)=>{
    try{
    const token= await req.body.token || req.headers["x-access-token"];
    const  decoded = jwt.verify(token,'TOKEN_KEY');
    req.user=decoded;
  } catch(error){
    return res.json({error:"invalid token"})
 }
   res.send("success")
}

module.exports={
  RegisterUser,LoginUser,getUser,verifytoken// exports logics & functions
}
