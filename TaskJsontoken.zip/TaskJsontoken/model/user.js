const Sequelize=require('sequelize')
const db=require('../config.js/database')// import sequelize to assign db

// create userModel
const Model=db.define('User',{
username:{
    type:Sequelize.STRING
},
email:{
    type:Sequelize.STRING,
},
password:{
    type:Sequelize.STRING
}},{
  freezeTableName:true
});
//create table using sync 
Model.sync();

//export the Model
module.exports=Model;