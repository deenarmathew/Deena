const express = require('express')
const app= express();
app.use(express.json());


const route=require('./route/user.route')
app.use('/',route)
app.listen(3000,()=>{
    console.log("app listen")

})