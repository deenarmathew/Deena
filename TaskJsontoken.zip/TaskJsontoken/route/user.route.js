const express= require('express')
const router=express.Router();

const usercontroller= require('../controller/user.controller');
//const auth=require('../middleware/auth') 


//methods

router.post('/signup', usercontroller.RegisterUser);

router.post('/signin', usercontroller.LoginUser);

router.get('/getall',usercontroller.getUser);

router.post('/home', usercontroller.verifytoken);


module.exports=router;