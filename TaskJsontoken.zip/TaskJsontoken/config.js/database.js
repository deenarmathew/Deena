const Sequelize =require('sequelize')
//sqlite connection
const sequelize= new Sequelize({
 dialect:'sqlite',
 storage:'deenadb.sqlite'
})

module.exports=sequelize;//export sequelize