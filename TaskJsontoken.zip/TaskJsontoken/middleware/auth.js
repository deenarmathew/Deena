/*const  jwt=require('jsonwebtoken')

exports.verifytoken=  async (req,res)=>{
    try{
    const token= await req.body.token || req.headers["x-access-token"];
    const  decoded = jwt.verify(token,'TOKEN_KEY');
    req.user=decoded;
  } catch(error){
    return res.json({error:"invalid token"})
 }
   res.send("success")
}*/

